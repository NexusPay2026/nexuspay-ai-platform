
from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
import sqlite3
import shutil
import uuid
import os

app = FastAPI(title="NexusPay AI Forensic Platform")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DB = "nexuspay.db"

def init_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("""
    CREATE TABLE IF NOT EXISTS audits(
        id TEXT PRIMARY KEY,
        filename TEXT,
        processor TEXT,
        volume REAL,
        fees REAL,
        rate REAL
    )
    """)
    conn.commit()
    conn.close()

init_db()

@app.get("/api/health")
def health():
    return {"status":"running"}

@app.post("/api/upload")
async def upload_statement(file: UploadFile = File(...)):
    os.makedirs("uploads", exist_ok=True)
    file_id = str(uuid.uuid4())
    path = f"uploads/{file_id}_{file.filename}"

    with open(path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # --- Simulated parsing engine ---
    volume = 284420
    fees = 8874
    rate = round((fees/volume)*100,2)
    processor = "Detected Processor"

    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("INSERT INTO audits VALUES (?,?,?,?,?,?)",
              (file_id,file.filename,processor,volume,fees,rate))
    conn.commit()
    conn.close()

    return {
        "audit_id":file_id,
        "processor":processor,
        "volume":volume,
        "fees":fees,
        "effective_rate":rate
    }

@app.get("/api/audits")
def list_audits():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    rows = c.execute("SELECT * FROM audits").fetchall()
    conn.close()

    audits = []
    for r in rows:
        audits.append({
            "id":r[0],
            "filename":r[1],
            "processor":r[2],
            "volume":r[3],
            "fees":r[4],
            "rate":r[5]
        })
    return audits
