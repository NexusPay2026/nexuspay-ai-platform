
NexusPay AI Merchant Statement Forensic Platform

Run locally:

1. Install Python 3.11+
2. pip install -r requirements.txt
3. uvicorn app:app --reload

Open:

http://localhost:8000

Features:

• Statement upload API
• Basic forensic fee calculation
• Audit database storage
• Booking calendar integration
• Ready for deployment
• Docker support

To deploy production:

Docker:
docker build -t nexuspay .
docker run -p 8000:8000 nexuspay

Cloud deployment supported:
AWS
Cloudflare
Render
Railway
